package mx.utng.s31;

import org.springframework.data.repository.CrudRepository;

public interface CasaRepository extends CrudRepository<Casa, Long>{
    
}
