package mx.utng.s31;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class S31Application {

	public static void main(String[] args) {
		SpringApplication.run(S31Application.class, args);
	}

}
